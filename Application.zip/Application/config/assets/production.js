'use strict';

module.exports = {
  client: {
    lib: {
      css: [
        'public/lib/bootstrap/dist/css/bootstrap.min.css',
        'public/lib/bootstrap/dist/css/bootstrap-theme.min.css',
		'public/lib/font-awesome/css/font-awesome.css',
		'public/lib/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.css',
		'public/lib/sweetalert/dist/sweetalert.css',
		'public/lib/jquery-ui/themes/black-tie/jquery-ui.min.css',
		'public/lib/angular-ui-select/dist/select.css',
		'public/lib/angular-ui-notification/dist/angular-ui-notification.css'
      ],
      js: [
		'public/lib/jquery/dist/jquery.min.js',
		'public/lib/jquery-ui/jquery-ui.min.js',
		'public/lib/moment/min/moment.min.js',
		'public/lib/angular/angular.min.js',
		'public/lib/angular-ui-date/dist/date.js',
		'public/lib/bootstrap/dist/js/bootstrap.min.js',
		'public/lib/angular-resource/angular-resource.min.js',
		'public/lib/angular-animate/angular-animate.min.js',
		'public/lib/angular-messages/angular-messages.min.js',
		'public/lib/angular-ui-router/release/angular-ui-router.min.js',
		'public/lib/angular-ui-utils/ui-utils.min.js',
		'public/lib/angular-bootstrap/ui-bootstrap-tpls.min.js',
		'public/lib/angular-ui-select/dist/select.min.js',
		'public/lib/angular-file-upload/angular-file-upload.min.js',
		'public/lib/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.concat.min.js',
		'public/lib/ng-scrollbars/dist/scrollbars.min.js',
		'public/lib/angular-local-storage/dist/angular-local-storage.min.js',
		'public/lib/ngSweetAlert/SweetAlert.min.js',
		'public/lib/sweetalert/dist/sweetalert.min.js',
		'public/lib/checklist-model/checklist-model.js'
      ]
    },
    css: 'public/dist/application.min.css',
    js: 'public/dist/application.min.js'
  }
};
