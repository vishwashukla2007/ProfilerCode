'use strict';

// Authentication service for user variables
angular.module('users').factory('Authentication', ['$window', 'localStorageService',
    function($window, localStorageService) {
        //var auth = {
        //user: $window.user
        //};
        var userdata = null;
        if (localStorageService.get("user") !== null) {
            userdata = localStorageService.get("user").data;
        }
        var auth = {
            user: userdata
        };
        return auth;
    }
]).factory('authWS', ['$resource',
    function($resource) {

        return $resource('/', {}, {
            signup: {
                url: "/api/auth/signup",
                method: "POST"
            },
            signin: {
                url: "/api/auth/signin",
                method: "POST"
            },
            signout: {
                url: "/api/auth/signout",
                method: "GET"
            }
        });
    }
]);
