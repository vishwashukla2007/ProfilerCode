'use strict';

angular.module('users').controller('EditProfileController', ['$scope', '$http', '$state', '$location', 'Users', 'Authentication', 'localStorageService',
    function($scope, $http, $state, $location, Users, Authentication, localStorageService) {
        $scope.user = Authentication.user;

        $scope.main = true;
        $scope.editProfile = false;

        var _user = localStorageService.get("user");
        $scope.user = _user.data;

        $scope.editProfile = function() {
            $scope.main = false;
            $scope.editProfile = true;
        };

        $scope.cancel = function() {
            $state.go($state.current, {}, {
                reload: true
            });
        };

        // Update a user profile
        $scope.updateUserProfile = function(isValid) {
            $scope.success = $scope.error = null;

            if (!isValid) {
                $scope.$broadcast('show-errors-check-validity', 'userForm');

                return false;
            }

            var user = new Users($scope.user);

            user.$update(function(response) {
                $scope.$broadcast('show-errors-reset', 'userForm');
                $scope.success = true;
                Authentication.user = response;
            }, function(response) {
                $scope.error = response.data.message;
            });
        };
    }
]);
