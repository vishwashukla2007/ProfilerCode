'use strict';

angular.module('users').controller('AuthenticationController', ['$scope', '$state', '$http', '$location', '$window', 'Authentication', 'PasswordValidator', 'localStorageService', 'authWS', 'SweetAlert',
    function($scope, $state, $http, $location, $window, Authentication, PasswordValidator, localStorageService, authWS, SweetAlert) {
        $scope.authentication = Authentication;
        $scope.popoverMsg = PasswordValidator.getPopoverMsg();

        // Get an eventual error defined in the URL query string:
        $scope.error = $location.search().err;

        // If user is signed in then redirect back home
        if ($scope.authentication.user) {
            $location.path('/');
        }

        $scope.signup = function(isValid) {
            $scope.error = null;

            if (!isValid) {
                $scope.$broadcast('show-errors-check-validity', 'userForm');

                return false;
            }

            authWS.signup($scope.credentials, function(res) {
                if (res.status === 200) {
                    $scope.authentication.user = res;
                    $state.go('mainview.duplicates' || 'home', $state.previous.params);
                }
            });

            // $http.post($window.apiUrl + '/api/auth/signup', $scope.credentials).success(function(response) {
            //     if (response.status === 400) {
            //         console.log("email or username already present");
            //     } else {
            //         $scope.authentication.user = response;
            //         $state.go('mainview.duplicates' || 'home', $state.previous.params);
            //     }

            // }).error(function(response) {
            //     $scope.error = response.message;
            // });
        };

        $scope.signin = function(isValid) {
            $scope.error = null;
            if (!isValid) {
                $scope.$broadcast('show-errors-check-validity', 'userForm');
                return false;
            }

            authWS.signin($scope.credentials, function(res) {
                if (res.status === 200) {
                    $scope.authentication.user = res.data[0];
                    $scope.$emit('userData', res);
                    localStorageService.set("user", res);
                    $state.go('mainview.duplicates', {
                        tab: 'dedup',
                        search:'',
                        pageNo: 1
                    },{reload: false});
                }else{
                    SweetAlert.swal(res.message, "", "error");
                }
            });

            // $http.post('/' + '/api/auth/signin', $scope.credentials).success(function(response) {
            //     if (response.status === 200) {
            //         $scope.authentication.user = response.data[0];
            //         localStorageService.set("user", response);
            //         $state.go('mainview.duplicates', $state.previous.params);
            //     } else if (response.status === 400) {
            //         alert(response.message);
            //     }

            // }).error(function(response) {
            //     $scope.error = response.message;
            // });
        };

        // OAuth provider request
        $scope.callOauthProvider = function(url) {
            if ($state.previous && $state.previous.href) {
                url += '?redirect_to=' + encodeURIComponent($state.previous.href);
            }

            // Effectively call OAuth authentication route:
            $window.location.href = url;
        };
    }
]);
