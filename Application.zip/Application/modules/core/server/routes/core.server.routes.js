'use strict';

module.exports = function(app) {

    // Root routing
    var core = require('../controllers/core.server.controller');
    var account = require('../controllers/accounts.server.controller');
    var contacts = require('../controllers/contacts.server.controller');
    var sf = require('../controllers/sf.server.controller');

    // Define error pages

    app.route('/server-error').get(core.renderServerError);

    // Return a 404 for all undefined api, module or lib routes
    app.route('/:url(api|modules|lib)/*').get(core.renderNotFound);


    // Define application route
    /* ROUTES FOR ACCOUNTS*/
    app.route('/*').get(core.renderIndex);
    app.route('/api/auth/duplicates/dup').post(account.getDuplicates);
    app.route('/api/auth/duplicates/updatedata').post(account.UpdateRecord);
    app.route('/api/auth/duplicates/getFinaldata').post(account.getFinaldata);
    app.route('/api/auth/duplicates/getdropdowndata').post(account.getdropdowndata);
    app.route('/api/auth/duplicates/getgroupdata').post(account.getgroupdata);
    app.route('/api/auth/duplicates/getfinalingroup').post(account.getfinalingroup);
    app.route('/api/auth/duplicates/getreviewedaccounts').post(account.getReviewedAccounts);
    app.route('/api/auth/duplicates/getfinalaccounts').post(account.getfinalAccounts);
    
    app.route('/sf/auth/login').post(sf.login);
    
    
    
    /* ROUTES FOR CONTACTS*/
     //fn_get_finalContactsforsfdc
     app.route('/api/auth/contacts/duplicates/updatedata').post(contacts.UpdateRecord);
     app.route('/api/auth/contacts/duplicates/dup').post(contacts.getDuplicates);
     app.route('/api/auth/contacts/duplicates/getdropdowndata').post(contacts.getdropdowndata);
     app.route('/api/auth/contacts/duplicates/getgroupdata').post(contacts.getgroupdata);
     app.route('/api/auth/contacts/duplicates/getfinalingroup').post(contacts.getfinalingroup);
     app.route('/api/auth/contacts/duplicates/getreviewedaccounts').post(contacts.getreviewedcontacts);
     app.route('/api/auth/contacts/duplicates/getfinalContacts').post(contacts.getfinalcontacts);
    /* ROUTES FOR CONTACTS END*/
    
    

};
