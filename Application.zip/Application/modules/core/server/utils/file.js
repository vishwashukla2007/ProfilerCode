'use strict';
var _ = require('lodash'),
    mkdirp = require('mkdirp'),
    mkpath = require('mkpath'),
    path = require('path'),
    fs = require('fs'),


    _config = {

        invoiceTargetPath: "public/files/invoice/",
        invoiceTargetDBPath: "files/invoice/",
    },
    _getExtension = function(mimeType) {
        switch (mimeType) {
            case 'image/jpeg':
                return '.jpg';
            case 'application/zip':
                return '.zip';
            case 'image/pjpeg':
                return '.jpg';
            case 'image/gif':
                return '.gif';
            case 'image/png':
                return '.png';
            case 'application/msword':
                return '.doc';
            case 'application/vnd.openxmlformats-officedocument.wordprocessingml.document':
                return '.docx';
            case 'application/excel':
            case 'application/vnd.ms-excel':
            case 'application/x-excel':
            case 'application/x-msexcel':
                return '.xls';
            case 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':
                return '.xlsx';
            case 'application/pdf':
                return '.pdf';
            default:
                return null;
        }
    },

    _addDocument = function(sourceFile, targetFile) {
       // console.log('sourceFile '+JSON.stringify(sourceFile));
        //console.log('targetFile '+JSON.stringify(targetFile));
        fs.writeFileSync(targetFile, fs.readFileSync(sourceFile));
    };


var multer = require('multer'),
    UPLOAD_PATH_PREFIX = "uploads/";

module.exports = {
    add: {
        
        document: {
            to: {
                invoice: function (targetPath, files, filename) {
                   // console.log('targetPath '+JSON.stringify(targetPath));
                   // console.log('filename '+JSON.stringify(filename));
                    // targetPath "public/files/invoice/36"
                   // filename "invoice_26"
                    if (typeof files.length != 'undefined') {
                       // console.log('length '+files.length);
                        _.forEach(files, function (file, index) {
                            var fileExt = _getExtension(file.mimetype);
                           // console.log('file '+JSON.stringify(file));
                           // file {"fieldname":"file","originalname":"retail equipment.jpg","encoding":"7bit","mimetype":"image/jpeg","destination":"./uploads/originals/invoice/","filename":"48f5946d55fc61101c0a3d802231f369","path":"uploads/originals/invoice/48f5946d55fc61101c0a3d802231f369","size":23294}
                            _addDocument(file.path, targetPath + "/" + file.filename+"_"+filename+ fileExt);
                        });

                    } else {
                        _addDocument(files.path, targetPath + "/" + filename + fileExt);
                    }
                }

            }
        }
    },
    config: _config,
    getExtension: _getExtension,
    upload: function(r) {}
};
