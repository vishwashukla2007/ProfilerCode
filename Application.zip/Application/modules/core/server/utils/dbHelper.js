/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

var config = require('./../../../../config/config.js');
var pg = require('pg');
//var config= require(path.resolve('./config/config'));
var Promise = require("bluebird");
var q = require('q');
Promise.promisifyAll(pg);

module.exports.connect = function () {

    console.log(config.pgdb.uri);
    var client = new pg.Client(config.pgdb.uri);
    client.connect(function (err) {
        if (err) {
            return console.error('could not connect to postgres', err);
        }
        client.query('SELECT NOW() AS "theTime"', function (err, result) {
            if (err) {
                return console.error('error running query', err);
            }
            console.log("AWANISH==$$$" + result.rows[0].theTime);
            //output: Tue Jan 15 2013 19:12:47 GMT-600 (CST) 
            client.end();
        });
    });
};

var handleError = function (err,client) {
    // no error occurred, continue with the request
    if (!err)
        return false;
    // An error occurred, remove the client from the connection pool.
    // A truthy value passed to done will remove the connection from the pool
    // instead of simply returning it to be reused.
    // In this case, if we have successfully received a client (truthy)
    // then it will be removed from the pool.
    if (client) {
        console.log(client);
        //done(client);
    }
    client.end();
    console.log('An error occurred' + err);
    return true;
};

module.exports.runQuery = function (query, param) {
    // get a pg client from the connection pool
    var client = new pg.Client(config.pgdb.uri);
    return new Promise(function (resolve, reject) {
        client.connect(function (err) {
            if (err) {
                //  return console.error('could not connect to postgres', err);
                reject('could not connect to postgres' + err);
                resolve(err);
            }
            client.query(query, param, function (err, result) {
                // handle an error from the query       
                if (handleError(err,client)){
                    
                    //console.log(err);
                     //reject('Error!==' + err);
                     resolve({rows:[]});
                    //return;
                }
                client.end();
                resolve(result);
                //return result;
                // get the total number of visits today (including the current visit)     
            });
        });
       
    });

};