 "use strict";

 var random = require("random-js")();

 module.exports.getRandom = function(inputData) {
     var outPut = "";
     try {
         var value = random.integer(1, 999999999);
         outPut = inputData + value;
     } catch (e) {
         outPut = inputData;
     }
     return outPut;
 };