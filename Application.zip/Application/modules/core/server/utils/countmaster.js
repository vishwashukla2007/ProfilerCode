'use strict';

var _ = require('lodash');
var path = require('path');
var mongoose = require('mongoose');
var counterMaster = mongoose.model('counter_master');
module.exports.getNextSequence = function() {
    return counterMaster.findOneAndUpdate({}, {
        $inc: {
            sequence: 1
        }
    }, {
        upsert: true
    });
};