var jsforce = require('jsforce');


exports.login = function (req, res) {

    var conn = new jsforce.Connection();

     conn.login('awanish.shukla@girikon.com', 'aks@girikon1j7x7OMI6NVFj6b645qASW8Y91', function (err, res1) {
        if (err) {
            
             res.json({
                    status: 200,
                    message: "error",
                    data: err
                });               
                
           
        }
        
       console.log(JSON.stringify( conn.PartnerAPI));

        conn.query('SELECT Id, Name,billingcity,billingstreet FROM Account', function (err, res1) {
            if (err) {
                res.json({
                    status: 200,
                    message: "error",
                    data: err
                });
            }
            
            
            res.json({
                    status: 200,
                    message: "data",
                    data: res1
                });
            
        });
    });
};

exports.mergeAccount = function (req, res) {
    
    
};

