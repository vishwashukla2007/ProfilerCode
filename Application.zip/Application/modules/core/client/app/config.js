'use strict';
// Init the application configuration module for AngularJS application
var ApplicationConfiguration = (function() {
    // Init module configuration options
    var applicationModuleName = 'mean';
    var applicationModuleVendorDependencies = ['ngResource', 'ngAnimate', 'ngMessages', 'ui.router', 'ui.date', 'ui.select',
        'ui.bootstrap', 'ui.utils', 'ui-notification', 'angularFileUpload', 'ngScrollbars', 'LocalStorageModule', 'oitozero.ngSweetAlert', 'checklist-model', 'ngFileUpload'
    ];
    // Add a new vertical module
    var registerModule = function(moduleName, dependencies) {
        // Create angular module
        angular.module(moduleName, dependencies || []);
        // Add the module to the AngularJS configuration file        
        //changes by awanish//    
        angular.module(moduleName).factory('authInterceptor' + moduleName, function($rootScope, $q, $window, localStorageService) {
            localStorageService.isrunning = false;
            return {
                request: function(config) {
                    config.headers = config.headers || {};
                    var ls = localStorageService.get("user");
                    //console.log(ls);
                    if (ls !== null && ls.token) {
                        config.headers.Authorization = 'Bearer ' + ls.token;
                        // console.log(config.headers.Authorization);
                    }
                    return config;
                },
                response: function(response) {
                    if (localStorageService.expiresin && false) {
                        if ((parseInt(ls.expires) - parseInt(moment().valueOf())) <= 60000 && !localStorageService.running) {
                            ls.running = true;
                            localStorageService.set("user", ls);
                            $.ajax({
                                url: "http://127.0.0.1:4000/api/private/refresh",
                                //url: "http://161.202.31.4:8081/api/private/refresh",
                                //url: "http://api.irontread.com/api/private/refresh",
                                type: "GET",
                                beforeSend: function(xhr) {
                                    xhr.setRequestHeader('authorization', 'Bearer ' + $localStorage.data.authToken);
                                },
                                success: function(data) {
                                    if (data.token != 'invalid') {
                                        ls.token = data.token;
                                        ls.expires = data.expires;
                                        ls.running = false;
                                        localStorageService.set("user", ls);
                                    }
                                },
                                error: function(error) {
                                    ls = null;
                                    localStorageService.set("user", ls);
                                }
                            });

                        }

                    }
                    if (response.status === 401) {
                        // handle the case where the user is not authenticated
                        return;
                    }
                    return response || $q.when(response);
                },
                responseError: function(rejection) {
                    if (rejection.status === 401) {
                        try {
                            ls = null;
                            // $state.go($state.current);
                        } catch (e) {

                        }
                    }
                    if (rejection.status === 403) {}
                }
            };
        });


        angular.module(moduleName).config(function($httpProvider) {
            $httpProvider.interceptors.push('authInterceptor' + moduleName);
        });

        angular.module(applicationModuleName).requires.push(moduleName);
    };
    ////////////////////////   

    return {
        applicationModuleName: applicationModuleName,
        applicationModuleVendorDependencies: applicationModuleVendorDependencies,
        registerModule: registerModule
    };
})();
