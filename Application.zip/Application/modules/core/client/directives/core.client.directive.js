'use strict';


angular.module('core').directive('setClassWhenAtTop', function($window) {
    var $win = angular.element($window);
    return {
        restrict: 'A',
        link: function(scope, element, attrs) {
            var topClass = attrs.setClassWhenAtTop,
                offsetTop = 40;
            $win.on('scroll', function(e) {
                if ($(window).scrollTop() >= offsetTop) {
                    element.addClass(topClass);
                } else {
                    element.removeClass(topClass);
                }
            });
        }
    };
}).directive('file', function() {
    return {
        restrict: 'E',
        template: '<input type="file" />',
        replace: true,
        require: 'ngModel',
        link: function(scope, element, attr, ctrl) {
            var listener = function() {
                scope.$apply(function() {
                    if (attr.multiple) {
                        ctrl.$setViewValue(element[0].files);
                    } else {
                        ctrl.$setViewValue(element[0].files[0]);
                    }
                });
            };
            element.bind('change', listener);
        }
    };
}).directive('fileModel', ['$parse',
    function($parse) {
        return {
            restrict: 'A',
            link: function(scope, element, attrs) {
                var model = $parse(attrs.fileModel);
                var modelSetter = model.assign;

                element.bind('change', function() {
                    scope.$apply(function() {
                        modelSetter(scope, element[0].files[0]);
                    });
                });
            }
        };
    }
]);
