'use strict';
angular.module('core').factory('multipartconverter', [

    function() {
        return function(data) {
            if (data === undefined)
                return data;
            var fd = new FormData();
            angular.forEach(data, function(value, key) {
                if (value instanceof FileList || (value instanceof Array && value.length > 0 && value[0] instanceof File)) {
                    angular.forEach(value, function(file, index) {
                        fd.append(key, file);
                    });
                } else {
                    fd.append(key, value);
                }
            });

            return fd;
        };
    }
]);

