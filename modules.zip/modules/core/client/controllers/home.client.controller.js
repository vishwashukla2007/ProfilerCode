'use strict';

angular.module('core').controller('HomeController', ['$scope', 'localStorageService', '$state', '$q',
    function($scope, localStorageService, $state, $q) {

    	 $scope.authentication = localStorageService.get('user');

    	 var height = $(window).height();

    	 if ($scope.authentication === null) {
    	 	$state.go('authentication.signin',{},{reload:true});
    	 }
    }
]);
