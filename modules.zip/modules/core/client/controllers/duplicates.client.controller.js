'use strict';

angular.module('core').controller('DuplicatesController', ['$scope', 'coreWS', 'SweetAlert', '$uibModal', 'localStorageService', '$rootScope', '$state','$window',
    function($scope, coreWS, SweetAlert, $uibModal, localStorageService, $rootScope,$state, $window) {

        $scope.data = [];
        $scope.dataView = true;
        $scope.totalCount = '';
        $scope.final = [];
        $scope.Allcoloums = {};
        $scope.coloumKeys = [];
        $scope.alphabet = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];

        $scope.search = {
            data: $state.params.search,
            pageNo: $state.params.pageNo,
            pagesize: 25,
            startBy: $state.params.startBy
        };

        $scope.stateName = $state.params.tab;

        $scope.changeUrl = function(search, no, alpha){
            $state.go($state.current,{tab: $state.params.tab, search: search,pageNo: no, startBy: alpha },{reload: false});
        };

        $scope.$watch('search.pageNo', function(newval, oldval){
            if (newval !== oldval) {
                $scope.changeUrl($scope.search.data, $scope.search.pageNo, $state.params.startBy);
            }
        });

        $scope.$watch('search.startBy', function(newval, oldval){
            if (newval !== oldval) {
                $scope.changeUrl($scope.search.data, $scope.search.pageNo, newval);
            }
        });

        var _selection = localStorageService.get('AccountSelectionV2');

        $scope.val = _selection;

        if (!_selection) {
            $scope.val = [{
                "ordinal_position": 1,
                "column_name": "id"
            },
            {
                "ordinal_position": 3,
                "column_name": "name"
            },
            {
                "ordinal_position": 5,
                "column_name": "billingstreet"
            },
            {
                "ordinal_position": 6,
                "column_name": "billingcity"
            },
            {
                "ordinal_position": 7,
                "column_name": "billingstate"
            },
            {
                "ordinal_position": 8,
                "column_name": "billingpostalcode"
            },
            {
                "ordinal_position": 9,
                "column_name": "billingcountry"
            },
            {
                "ordinal_position": 10,
                "column_name": "phone"
            },
            {
                "ordinal_position": 22,
                "column_name": "other_phone"
            },
            {
                "ordinal_position": 27,
                "column_name": "tollfree"
            },
            {
                "ordinal_position": 12,
                "column_name": "website"
            },
            {
                "ordinal_position": 26,
                "column_name": "eventseries"
            }];
            localStorageService.set('AccountSelectionV2', $scope.val);
        }

        $scope.getColoumKeys = function() {
            $scope.coloumKeys = [];
            var selectionLocal = localStorageService.get('AccountSelectionV2');
            angular.forEach(selectionLocal, function(value, key) {
                if(value.column_name != 'id'){
                    $scope.coloumKeys.push(value.column_name);
                }
            });
        };

        $scope.dropDownData = function(deDupData) {
            coreWS.getdropdowndata({}, function(res) {
                if (res.status === 200) {
                    angular.forEach(res.data, function(value, key) {
                        $scope.Allcoloums[value.column_name] = value.ordinal_position;
                    });
                    $scope.getColoumKeys();
                    $scope.data = deDupData.data;
                    $scope.dataView = false;
                    if ($scope.data === null) {
                        $scope.totalCount = 0;
                    }
                    else{
                        $scope.totalCount = $scope.data[0].total_entries_count;
                        angular.forEach($scope.data, function(value, key) {
                            $scope.populateFinal(value.m_group_id, value.item);
                        });
                    }
                }
            });
        };
        

        $scope.duplicates = function(value, alpha) {
                $scope.search.startBy = alpha;
                $scope.data = [];
                $scope.dataView = true;
                if (value) {
                    $scope.search.pageNo = 1;
                }
                if ($state.params.tab === 'dedup') {
                    coreWS.getduplicates({
                        "searchtext": $scope.search.data,
                        "page": $scope.search.pageNo,
                        "pagesize": $scope.search.pagesize,
                        "startBy":  $state.params.startBy
                    }, function(res) {
                        if (res.status === 200) {
                            $scope.dropDownData(res);
                        }
                    });
                }else if ($state.params.tab === 'reviewed') {
                    coreWS.getreviewedaccounts({
                            "searchtext": $scope.search.data,
                            "page": $scope.search.pageNo,
                            "pagesize": $scope.search.pagesize
                        }, function(res) {
                            if (res.status === 200) {
                                $scope.dropDownData(res);
                            }
                        });
                }else if ($state.params.tab === 'finalreviewed') {
                    coreWS.getfinalreviewedaccounts({
                            "searchtext": $scope.search.data,
                            "page": $scope.search.pageNo,
                            "pagesize": $scope.search.pagesize
                        }, function(res) {
                            if (res.status === 200) {
                                $scope.dropDownData(res);
                            }
                        });
                }
        };
        $scope.duplicates();

        $scope.getOrdinal = function(action) {
            if ($scope.Allcoloums.hasOwnProperty(action)) {
                return '$$' + $scope.Allcoloums[action] + '$$';
            }
            return -1;
        };

        $scope.deleteNpush = function(_groupId, data) {
            angular.forEach($scope.data, function(value, key) {
                if (value.m_group_id === _groupId) {
                    $scope.data.splice(key, 1, data[0]);
                }
            });
        };

        $scope.delete = function(_groupId) {
            angular.forEach($scope.data, function(value, key) {
                if (value.m_group_id === _groupId) {
                    $scope.data.splice(value, 1);
                }
            });
        };

        $scope.confirmSelection = function(saText,saType,id, action, groupID, userid, _ordinal, successMsg) {
            swal({
                title: "Are you sure?",
                text: saText,
                type: saType,
                showCancelButton: true,
                confirmButtonColor: "#DEB887",
                confirmButtonText: "Yes",
                cancelButtonText: "No",
                closeOnConfirm: false,
                closeOnCancel: true
            },
            function(isConfirm) {
                if (isConfirm) {
                    $scope.finalAction(id, action, groupID, userid, _ordinal,successMsg,"");
                } 
            });
        };

        $scope.confirmSelectionWithComment = function(saText,id, action, groupID, userid, _ordinal, successMsg) {
            swal({
                title: "Are you sure?",
                text: saText,
                type: "input",
                showCancelButton: true,
                confirmButtonColor: "#DEB887",
                confirmButtonText: "Yes",
                cancelButtonText: "No",
                closeOnConfirm: false,
                closeOnCancel: true,
                inputPlaceholder: "Write comment here.."
            },
            function(inputValue) {
                if (inputValue !== false) {
                    $scope.finalAction(id, action, groupID, userid, _ordinal, successMsg,inputValue);
                } 
            });
        };

        $scope.doAction = function(id, action, groupID, userid, _ordinal, deci, winner) {
            if (deci !== 1) {
                if (action === 'nd') {
                    if (winner === 0) {
                        $scope.confirmSelection("You want to delink this row.","warning"
                        ,id, action, groupID, userid, _ordinal,"Your data has been delinked.");
                    }
                    else{
                        swal("Please choose a Winner, before delinking this row.");
                    }
                } 
                else if (action === 'over') {
                    $scope.confirmSelectionWithComment("You want to finalize this data.",
                    id, action, groupID, userid, _ordinal,"Your data has been finalized.");
                } 
                else if (action === 'winner') {
                    if (winner === 0) {
                        $scope.confirmSelection("You want to change winner.","info"
                        ,id, action, groupID, userid, _ordinal,"Your data has been finalized.");
                    }
                    else{
                        swal("This row is already a winner.");
                    }
                } 
                else if (action === 'revert') {
                    $scope.confirmSelectionWithComment("You want to revert your decision.",
                    id, action, groupID, userid, _ordinal,"Your data has been reveted to previous");
                }
                else if (action === 'finalreview') {
                    $scope.confirmSelectionWithComment("You want to mark final record as reviewed.",
                    id, action, groupID, userid, _ordinal,"");
                }
                else if (action === 'undofinalreview') {
                    $scope.confirmSelectionWithComment("You want to revert the reviewed status.",
                    id, action, groupID, userid, _ordinal,"");
                }
                else if (action === 'donotmigrate') {
                    $scope.confirmSelectionWithComment("You want to mark record as do not migrate.",
                    id, action, groupID, userid, _ordinal,"");
                }
                else if (action === 'undodonotmigrate') {
                    $scope.confirmSelectionWithComment("You want to revert the record as do not migrate.",
                    id, action, groupID, userid, _ordinal,"");
                }
                else if (action === 'MKGP') {
                    var selLength = ($scope[groupID]===undefined?(0):($scope[groupID].length));
                     if(selLength<2){
                         swal("Select atleast 2 records to create new group!");
                         return;
                     }
                     $scope.confirmSelection("You want to create new group.","info"
                     ,id, action+'='+$scope[groupID], groupID, userid, _ordinal,"new group has been created.");
                }
                else if (!winner) {
                    $scope.finalAction(id, action, groupID, userid, _ordinal,null,"");
                }
            }
        };

        $scope.finalAction = function(id, action, groupID, userid, _ordinal, successMsg, comment) {
            coreWS.updatedata({
                id: id,
                ordinal: _ordinal,
                action: action,
                group_id: groupID,
                userid: userid,
                comment: comment.trim().split("'").join("''")
            }, function(res) {
                if (res.status === 200) {
                    if (res.data) {
                        if(res.data[0].errormessage !== ""){
                            swal("Error!", res.data[0].errormessage, "error");
                        }
                        else{
                            if(successMsg !== null){
                                swal("Success!", successMsg, "success");
                            }
                        }
                        var data1 = res.data;
                        if(res.data != null){
                            var data = res.data[0].item;
                            data = $scope.populateFinal(groupID, data);
                            data1.item = data;
                            $scope.deleteNpush(groupID, data1);
                            if (action === 'over' || action === 'revert' || action.indexOf('MKGP=')>-1 
                            || action === 'finalreview' || action === 'undofinalreview') {
                                $scope.duplicates();
                            }
                        }
                    }else{
                        $scope.duplicates();
                    }                    
                }
            });
        };

        $scope.finalData = function() {
            coreWS.getFinaldata({}, function(res) {
                if (res.status === 200) {
                    $scope.final = res.data;
                }
            })
        };

        $scope.populateFinal = function(groupID, data) {
            var selections = '0';
            angular.forEach($scope.val, function(value, key) {
                selections = selections + ',' + value.ordinal_position;
            });

            coreWS.getfinalingroup({
                groupId: groupID,
                SELECTIONS: selections
            }, function(res) {
                if (res.status === 200) {
                    if (res.data != null) {
                        var data1 = res.data[0];
                        for (var i = 0; i < data.length; i++) {
                            data1.final_decision = 1;
                            if (data[i].decision === 0) {
                                data1.final_decision = 0;
                                break;
                            }
                        }
                        data1.final = true;
                        data.push(data1);
                    }
                }
                //console.log(JSON.stringify($scope.data));
            });
        };

       $rootScope.$on('refresh', function(event, data) {
            if (data) {
                var newOrdinal = '$$' + data.ordinal + '$$';
                angular.forEach($scope.data, function(value, key) {
                      angular.forEach(value.item, function(v, k){
                        if(v.selections){
                            if (data.Id === value.m_group_id && v.selections.indexOf(newOrdinal) > -1) {
                                v.selections = v.selections.replace(newOrdinal,'');
                            }
                        }
                        if (data.Id === value.m_group_id && data.accId === v.m_values) {
                            v.selections = v.selections + newOrdinal;
                        }
                      });
                });
            }
        });
        
        $scope.forNewGroup = function(id,groupid,ischecked) {  
            if( typeof($scope[groupid])=== 'undefined'){
                $scope[groupid] = []; 
            }           
            if(ischecked==true){
                if($scope[groupid].indexOf(id)==-1){
                    $scope[groupid].push(id);
                }
              }
            else{
                var A = $scope[groupid];
                A = A.filter(e => e !== id);
                //console.log(A);
                $scope[groupid] = A;
            }
            //console.log("groupvalue=="+$scope[groupid]);
        };
        
        $scope.openModalPopup = function(service) {
            var modalInstance = $uibModal.open({
                templateUrl: 'popup.html',
                controller: 'popupCtrl',
                size: 'xl',
                resolve: {
                    data: function() {
                        return service;
                    }
                }
            }).result.then(function () {
                $scope.getColoumKeys();
                if(service.item[service.item.length - 1].final)
			    {
                    service.item.splice(service.item.length - 1, 1);
                }
                $scope.populateFinal(service.m_group_id,service.item);
              }, function () {
                $scope.getColoumKeys();
                if(service.item[service.item.length - 1].final)
			    {
                    service.item.splice(service.item.length - 1, 1);
                }
                $scope.populateFinal(service.m_group_id,service.item);
              });
        };

        $scope.openCommentsPopup = function(service) {
            var modalInstance = $uibModal.open({
                templateUrl: 'popupcomment.html',
                controller: 'popupcommentCtrl',
                size: 'xl',
                resolve: {
                    data: function() {
                        return service;
                    }
                }
            });
        };
    }
]).controller('popupCtrl', ['$scope', 'coreWS', 'SweetAlert', '$uibModalInstance', 'data', 'localStorageService',
    function($scope, coreWS, SweetAlert, $uibModalInstance, data, localStorageService) {

        $scope.service = data.item;
        $scope.Allcoloums = [];
        $scope.coloums = [];
        $scope.selected = {};
        $scope.selected.coloum = [];

        var _selection = localStorageService.get('AccountSelectionV2');
        var groupID = '';
        $scope.selected.coloum = _selection;
        $scope.val = _selection;
		
		$scope.filterColumns = function() {
            $scope.coloums = [];
			angular.forEach($scope.Allcoloums, function(valueCols, keyCols) {
				var isExist = false;
                angular.forEach($scope.val, function(value, key) {
					if(valueCols.column_name == value.column_name){
						isExist = true;
					}
				});
				if(!isExist){
					$scope.coloums.push(valueCols);
				}
            });
			//console.log($scope.coloums);
        };
		
		$scope.groupData = function(value) {
			var existingcolums = [];
			angular.forEach($scope.val, function(value, key) {
                existingcolums.push(value.column_name);
            });
            if (value) {
                for (var i = 0; i < value.length; i++) {
                    if (existingcolums.indexOf(value[i].column_name) == -1) {
                        $scope.val.push(value[i]);
                    }
                }
                localStorageService.set('AccountSelectionV2', $scope.val);
            }
			
			$scope.filterColumns();
            var _value = localStorageService.get('AccountSelectionV2');
            var selections = '0';
            angular.forEach($scope.val, function(value, key) {
                selections = selections + ',' + value.ordinal_position;
            });
            coreWS.getgroupdata({
                groupId: data.m_group_id,
                data: selections
            }, function(res) {
                if (res.status === 200) {
                    groupID = res.data[0].m_group_id;
                    $scope.service = res.data[0].item;
                    $scope.populateFinal(data.m_group_id, $scope.service)
                }
            });
        };

        $scope.dropDownData = function() {
            coreWS.getdropdowndata({}, function(res) {
                if (res.status === 200) {
                    $scope.Allcoloums = res.data;
					$scope.groupData();
                }
            });
        };
        $scope.dropDownData();

        $scope.keys_2 = function(obj) {
            return obj ? Object.keys(obj) : [];
        }

        $scope.keys = function(obj) {
            var _value = localStorageService.get('AccountSelectionV2');
            if(_value != null){
                var listColumnNames = [];
                angular.forEach(_value, function(value, key) {
                    listColumnNames.push(value.column_name);
                });
                //console.log(listColumnNames);
                return listColumnNames;
            }
            else{
                return obj ? Object.keys(obj) : [];
            }
        }

        $scope.getOrdinal = function(action) {
            for (var i = 0; i < $scope.val.length; i++) {
                if ($scope.val[i].column_name === action) {
                    var _ordinal = $scope.val[i].ordinal_position;
                    return '$$' + _ordinal + '$$';
                }
            }
            return -1;
        };

        $scope.doAction = function(id, action, userid, finalV, acc_Id) {
			if($scope.service[$scope.service.length - 1].desesion != 1 && $scope.service[$scope.service.length - 1].desesion != undefined)
			{
				if (action !== 'id' && !finalV) {
					var _ordinal = '';
					for (var i = 0; i < $scope.val.length; i++) {
						if ($scope.val[i].column_name === action) {
							_ordinal = $scope.val[i].ordinal_position;
							break;
						}
					}

					coreWS.updatedata({
						id: id,
						ordinal: _ordinal,
						action: action,
						group_id: groupID,
						userid: userid
					}, function(res) {
						if (res.status === 200) {
							var data1 = res.data;
							var data = res.data[0].item;
							$scope.groupData(groupID);
							data = $scope.populateFinal(groupID, data);
							data1.item = data;
							var senddata = {
								Id: groupID,
								accId: acc_Id,
								ordinal: _ordinal
							};
							$scope.$emit('refresh', senddata);
						}
					});
				}
			}
        };

        $scope.checkColoum = function(array, needle) {
            for (var i = 0; i < array.length; i++) {
                if (array[i].column_name == needle) {
                    return true;
                }
            }
            return false;
        };

        $scope.populateFinal = function(groupID, data) {
            var selections = '0';
            angular.forEach($scope.val, function(value, key) {
                selections = selections + ',' + value.ordinal_position;
            });

            coreWS.getfinalingroup({
                groupId: groupID,
                SELECTIONS: selections
            }, function(res) {
                if (res.status === 200) {
                    var data1 = res.data[0];
                    data1.final = true;
                    data.push(data1);
                }
            });
        };

        $scope.removeChoice = function(value) {
            var index = $scope.val.indexOf(value);
            $scope.val.splice(index, 1);
            localStorageService.set('AccountSelectionV2', $scope.val);
			$scope.filterColumns();
        };

        $scope.close = function() {
            $uibModalInstance.close(true);
        };
    }
]).controller('popupcommentCtrl', ['$scope', 'coreWS', '$uibModalInstance', 'data',
    function($scope, coreWS, $uibModalInstance, data) {
        $scope.comments = [];
        $scope.groupid = data.m_group_id;

        $scope.geComments = function() {
            coreWS.getcomments({
                groupid: $scope.groupid,
                objectname: 'account'
            }, 
            function(res) {
                if (res.status === 200) {
                    $scope.comments = res.data;
                }
            });
        };
        $scope.geComments();

        $scope.close = function() {
            $uibModalInstance.close(true);
        };
    }
]).controller('FinalController', ['$scope', 'coreWS', 'SweetAlert', 'localStorageService', '$state',
    function($scope, coreWS, SweetAlert, localStorageService, $state) {

        $scope.tabName = $state.params.tab;
        $scope.data = [];
        $scope.totalCount = '';

        $scope.search = {
            data: '',
            pageNo: 1,
            pagesize: 50
        }

        $scope.getData = function(){
            if ($state.params.tab === 'accounts') {
                coreWS.getfinalaccounts({
                    "searchtext": $scope.search.data,
                    "page": $scope.search.pageNo,
                    "pagesize": $scope.search.pagesize
                }, function(res) {
                    if (res.status === 200) {
                        $scope.data = res.data;
                        $scope.totalCount = res.data[0].total_entries_count;
                    }
                });
            }else {
                coreWS.getfinalContacts({
                    "searchtext": $scope.search.data,
                    "page": $scope.search.pageNo,
                    "pagesize": $scope.search.pagesize
                }, function(res) {
                    if (res.status === 200) {
                        $scope.data = res.data;
                        $scope.totalCount = res.data[0].total_entries_count;
                    }
                });
            }
        };
        $scope.getData();
    }
]);
