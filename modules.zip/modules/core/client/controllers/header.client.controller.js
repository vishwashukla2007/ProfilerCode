'use strict';

angular.module('core').controller('HeaderController', ['$scope', '$state', 'Authentication', 'Menus', 'localStorageService', '$rootScope',
    function($scope, $state, Authentication, Menus, localStorageService, $rootScope) {
        // Expose view variables

        $scope.$state = $state;
        var d = new Date();
        var n = d.getTime();

        $rootScope.$on('userData', function(event, data) {
            $scope.authentication = data;
        });

        $scope.authentication = localStorageService.get('user');

        if ($scope.authentication !== null && n > $scope.authentication.expires) {
            localStorageService.remove("user");
        }

        // Get the topbar menu
        $scope.menu = Menus.getMenu('topbar');

        // Toggle the menu items
        $scope.isCollapsed = false;
        $scope.toggleCollapsibleMenu = function() {
            $scope.isCollapsed = !$scope.isCollapsed;
        };

        // Collapsing the menu after navigation
        $scope.$on('$stateChangeSuccess', function() {
            $scope.isCollapsed = false;
        });

        /*Logout function*/
        $scope.logout = function() {
            $scope.authentication.user = null;
            localStorageService.remove("user");
            window.location.href = '/';
            //$state.go('authentication.signin',{},{reload:true});
        };
    }
]);
