'use strict';
angular.module('core').factory('coreWS', ['$resource',
    function($resource) {

        return $resource('/', {}, {
            getduplicates: {
                url: "/api/auth/duplicates/dup",
                method: "POST"
            },
            updatedata: {
                url: "/api/auth/duplicates/updatedata",
                method: "POST"
            },
            getFinaldata: {
                url: "/api/auth/duplicates/getFinaldata",
                method: "POST"
            },
            getdropdowndata: {
                url: "/api/auth/duplicates/getdropdowndata",
                method: "POST"
            },
            getgroupdata: {
                url: "/api/auth/duplicates/getgroupdata",
                method: "POST"
            },
            getfinalingroup: {
                url: "/api/auth/duplicates/getfinalingroup",
                method: "POST"
            },
            getreviewedaccounts: {
                url: "/api/auth/duplicates/getreviewedaccounts",
                method: "POST"
            },
            getfinalaccounts: {
                url: "/api/auth/duplicates/getfinalaccounts",
                method: "POST"
            },
            getcontactduplicates: {
                url: "/api/auth/contacts/duplicates/dup",
                method: "POST"
            },
            getcontactdropdowndata: {
                url: "/api/auth/contacts/duplicates/getdropdowndata",
                method: "POST"
            },
            getcontactgroupdata: {
                url: "/api/auth/contacts/duplicates/getgroupdata",
                method: "POST"
            },
            getcontactfinalingroup: {
                url: "/api/auth/contacts/duplicates/getfinalingroup",
                method: "POST"
            },
            contactupdatedata: {
                url: "/api/auth/contacts/duplicates/updatedata",
                method: "POST"
            },
            getreviewedcontact: {
                url: "/api/auth/contacts/duplicates/getreviewedaccounts",
                method: "POST"
            },
            getfinalContacts: {
                url: "/api/auth/contacts/duplicates/getfinalContacts",
                method: "POST"
            },
            getfinalreviewedaccounts: {
                url: "/api/auth/duplicates/getfinalreviewedaccounts",
                method: "POST"
            },
            getfinalreviewedcontact: {
                url: "/api/auth/contacts/duplicates/getfinalreviewedcontact",
                method: "POST"
            },
            getcomments: {
                url: "/api/auth/duplicates/getcomments",
                method: "POST"
            }
        });
    }
]);
