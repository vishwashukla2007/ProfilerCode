/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

var config = require('./../../../../config/config.js');
var path = require('path');
var dbHelper = require(path.resolve('./modules/core/server/utils/dbHelper'));
var pg = require('pg');

exports.UpdateRecord = function(req, res) {

    var userId = req.user.id;
    // var userId = 1; //req.user._id,
    var id = req.body.id;
    var group_id = req.body.group_id;
    var action = req.body.action;
    var ordinal = req.body.ordinal;



    if (typeof(userId) === 'undefined') {
        res.json({
            status: 400,
            message: "you are not logged in"
        });
    }

    try {

        //var actionQuery = "select fn_set_selections($1,$2,$3,$4);";

        var actionQuery = "select fn_set_selections_dynamic(" + id + "," + ordinal + ",'" + action + "'," + group_id + "," + userId + ");";
        //console.log("actionQuery " + actionQuery);
        var actionInfo = dbHelper.runQuery(actionQuery, []);

        actionInfo.then(function(record) {
            //console.log('supplier' + JSON.stringify(supplier));
            if (record.length === 0) {

                res.json({
                    status: 400,
                    data: "some error"
                });

            } else {
                res.json({
                    status: 200,
                    message: "action info",
                    data: JSON.parse(record.rows[0].fn_set_selections_dynamic) //JSON.parse(duplicates.rows.data[0].fn_get_duplicates)
                });
            }
        });

    } catch (e) {
        res.json({
            "data": e
        });
    }


}


exports.getDuplicates = function(req, res) {

    try {

        var userId = 1; //req.user._id,
        var searchtext = req.body.searchtext;
        var page = req.body.page;
        var pagesize = req.body.pagesize;
        var startBy = req.body.startBy;
        var userId = req.user.id;

        //console.log("startBy=="+startBy);

        if (typeof(userId) === 'undefined') {
            res.json({
                status: 400,
                message: "you are not logged in"
            });
        }

        var dupQuery ="";
        if(startBy){
             dupQuery = "select fn_get_duplicates_startby('" + searchtext + "','" + startBy + "'," + page + "," + pagesize + ", "+userId+");";
        }else{
             dupQuery = "select fn_get_duplicates('" + searchtext + "'," + page + "," + pagesize + ","+userId+");";
        }

        //console.log("dupQuery=="+dupQuery);
              
        var dupInfo = dbHelper.runQuery(dupQuery, []);

        dupInfo.then(function(duplicates) {

            if (duplicates.length === 0) {
                res.json({
                    status: 400,
                    data: "there is no any duplicated"
                });

            } else {
                if(startBy){
                    res.json({
                        status: 200,
                        message: "duplicates",
                        data: JSON.parse(duplicates.rows[0].fn_get_duplicates_startby) //JSON.parse(duplicates.rows.data[0].fn_get_duplicates)
                    });
                } else {
                    res.json({
                        status: 200,
                        message: "duplicates",
                        data: JSON.parse(duplicates.rows[0].fn_get_duplicates) //JSON.parse(duplicates.rows.data[0].fn_get_duplicates)
                    });
                }
            }
        });

    } catch (e) {
        res.json({
            "data": e
        });
    }
};


exports.getfinalingroup = function(req, res) {

    try {

        //var userId = 1; //req.user._id,
        var userId = req.user.id;

        if (typeof(userId) === 'undefined') {
            res.json({
                status: 400,
                message: "you are not logged in"
            });
        }
        var searchtext = req.body.groupId;
        var SELECTIONS = req.body.SELECTIONS;
        var dupQuery = "select fn_get_finaldata('" + searchtext + "','" + SELECTIONS + "');";
        var dupInfo = dbHelper.runQuery(dupQuery, []);

        dupInfo.then(function(duplicates) {
            //console.log('supplier' + JSON.stringify(supplier));
            if (duplicates.length === 0) {

                res.json({
                    status: 400,
                    data: "there is no any duplicated"
                });

            } else {
                res.json({
                    status: 200,
                    message: "duplicates",
                    data: JSON.parse(duplicates.rows[0].fn_get_finaldata) //JSON.parse(duplicates.rows.data[0].fn_get_duplicates)
                });
            }
        });

    } catch (e) {
        res.json({
            "data": e
        });
    }
};


exports.getFinaldata = function(req, res) {

    try {

        var userId = req.user.id;

        if (typeof(userId) === 'undefined') {
            res.json({
                status: 400,
                message: "you are not logged in"
            });
        }

        var dupQuery = "select fn_get_merged('a',1,50);";
        //console.log("warehouseQuery " + warehouseQuery);
        var dupInfo = dbHelper.runQuery(dupQuery, []);

        dupInfo.then(function(duplicates) {
            //console.log('supplier' + JSON.stringify(supplier));
            if (duplicates.length === 0) {

                res.json({
                    status: 400,
                    data: "there is no any duplicated"
                });

            } else {
                res.json({
                    status: 200,
                    message: "final data",
                    data: JSON.parse(duplicates.rows[0].fn_get_merged) //JSON.parse(duplicates.rows.data[0].fn_get_duplicates)
                });
            }
        });

    } catch (e) {
        res.json({
            "data": e
        });
    }
};

exports.getdropdowndata = function(req, res) {
    try {
        var userId = req.user.id;

        if (typeof(userId) === 'undefined') {
            res.json({
                status: 400,
                message: "you are not logged in"
            });
        }
        var selectQuery = "select fn_get_columns();";
        var selectInfo = dbHelper.runQuery(selectQuery, []);

        selectInfo.then(function(duplicates) {
            if (duplicates.length === 0) {
                res.json({
                    status: 400,
                    data: "no data"
                });
            } else {
                res.json({
                    status: 200,
                    message: "final data",
                    data: JSON.parse(duplicates.rows[0].fn_get_columns)
                });
            }
        });
    } catch (e) {
        res.json({
            "data": e
        });
    }
};

exports.getgroupdata = function(req, res) {
    try {

        var groupId = parseInt(req.body.groupId),
            array = req.body.data;

        var userId = req.user.id;

        if (typeof(userId) === 'undefined') {
            res.json({
                status: 400,
                message: "you are not logged in"
            });
        }
        var dupQuery = "select fn_get_groupdata(" + groupId + ",'" + array + "');";
        var dupInfo = dbHelper.runQuery(dupQuery, []);
        console.log(dupQuery);
        dupInfo.then(function(duplicates) {
            if (duplicates.length === 0) {
                res.json({
                    status: 400,
                    data: "no data found"
                });
            } else {
                res.json({
                    status: 200,
                    message: "success",
                    data: JSON.parse(duplicates.rows[0].fn_get_groupdata)
                });
            }
        });
    } catch (e) {
        res.json({
            "data": e
        });
    }
};


exports.getReviewedAccounts = function(req, res){
    
        checklogin(req, res);
        //var userId = req.user._id;
        var searchtext = req.body.searchtext;
        var page = req.body.page;
        var pagesize = req.body.pagesize;
        var userId = req.user.id;
        var dupQuery = "select fn_get_reviewedaccounts('" + searchtext + "'," + page + "," + pagesize + ","+userId+");";
        runQueryNResult(req, res,dupQuery,'fn_get_reviewedaccounts',[]);    
}

exports.getfinalAccounts = function(req, res){
    
        checklogin(req, res);
        //var userId = req.user._id;
        var searchtext = req.body.searchtext;
        var page = req.body.page;
        var pagesize = req.body.pagesize;
        var userId = req.user.id;
        var dupQuery = "select fn_get_finalaccountsforsfdc('" + searchtext + "'," + page + "," + pagesize + ","+userId+");";
        runQueryNResult(req, res,dupQuery,'fn_get_finalaccountsforsfdc',[]);    
}




function checklogin(req, res){
     var userId = req.user.id;

        if (typeof(userId) === 'undefined') {
            res.json({
                status: 400,
                message: "you are not logged in"
            });
        }
}
function runQueryNResult(req, res,Query,spname,parm){    
       var QueryInfo = dbHelper.runQuery(Query, parm);

        QueryInfo.then(function(duplicates) {
            //console.log('supplier' + JSON.stringify(supplier));
            if (duplicates.length === 0) {
                res.json({
                    status: 400,
                    data: "problem in running query"
                });

            } else {
                res.json({
                    status: 200,
                    message: "data",
                    data: JSON.parse(duplicates.rows[0][""+spname+""]) 
                });
            }
        });
    
}

