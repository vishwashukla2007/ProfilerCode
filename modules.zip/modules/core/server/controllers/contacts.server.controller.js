/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var config = require('./../../../../config/config.js');
var path = require('path');
var dbHelper = require(path.resolve('./modules/core/server/utils/dbHelper'));
var pg = require('pg');


exports.getdropdowndata  = function(req, res) {
    
      checklogin(req, res);
      var searchtext = req.body.searchtext;
      var page = req.body.page;
      var pagesize = req.body.pagesize;
      var userId = 1;//req.user.id;
      var dupQuery = "select fn_get_contact_columns();";
      runQueryNResult(req, res,dupQuery,'fn_get_contact_columns',[]);   
    
}


exports.getDuplicates = function(req, res){    
        checklogin(req, res);
        //var userId = req.user._id;
        var searchtext = req.body.searchtext;
        var page = req.body.page;
        var pagesize = req.body.pagesize;
        var startBy = req.body.startBy;
        var userId = req.user.id;

        var dupQuery ="";
        if(startBy){
             dupQuery = "select fn_get_contact_duplicates_startby('" + searchtext + "','" + startBy + "'," + page + "," + pagesize + ", "+userId+");";
             runQueryNResult(req, res, dupQuery,'fn_get_contact_duplicates_startby',[]);
        }else{
             dupQuery = "select fn_get_contact_duplicates('" + searchtext + "'," + page + "," + pagesize + ","+userId+");";
             runQueryNResult(req, res, dupQuery,'fn_get_contact_duplicates',[]);
        }
        //var dupQuery = "select fn_get_contact_duplicates('" + searchtext + "'," + page + "," + pagesize + ","+userId+");";
         // runQueryNResult(req, res,dupQuery,'fn_get_contact_duplicates',[]);
}

exports.getreviewedcontacts =  function(req, res){    
    checklogin(req, res);
    var searchtext = req.body.searchtext;
    var page = req.body.page;
    var pagesize = req.body.pagesize;
    var userId = req.user.id;
    var dupQuery = "select fn_get_reviewedcontact('" + searchtext + "'," + page + "," + pagesize + ","+userId+");";
    runQueryNResult(req, res,dupQuery,'fn_get_reviewedcontact',[]);
}

exports.getFinalReviewedContact =  function(req, res){    
    checklogin(req, res);
    var searchtext = req.body.searchtext;
    var page = req.body.page;
    var pagesize = req.body.pagesize;
    var userId = req.user.id;
    var dupQuery = "select fn_get_final_reviewedcontact('" + searchtext + "'," + page + "," + pagesize + ","+userId+");";
    runQueryNResult(req, res,dupQuery,'fn_get_final_reviewedcontact',[]);
}

exports.getfinalcontacts =  function(req, res){    
    //checklogin(req, res);
    var searchtext = req.body.searchtext;
    var page = req.body.page;
    var pagesize = req.body.pagesize;
    var userId = 1;//req.user.id;
    var dupQuery = "select fn_get_finalcontactsforsfdc('" + searchtext + "'," + page + "," + pagesize + ","+userId+");";
    console.log(dupQuery);
    runQueryNResult(req, res,dupQuery,"fn_get_finalcontactsforsfdc",[]);
}

exports.getgroupdata =  function(req, res){    
    checklogin(req, res);
    var groupId = parseInt(req.body.groupId);
    var array = req.body.data;
    var userId = req.user.id;
    var dupQuery = "select fn_get_contact_groupdata(" + groupId + ",'" + array + "');";
    runQueryNResult(req, res,dupQuery,'fn_get_contact_groupdata',[]);
}
//fn_get_contact_finaldata

exports.getfinalingroup = function(req, res) {
    checklogin(req, res);
    var searchtext = req.body.groupId;
    var SELECTIONS = req.body.SELECTIONS;    
    var userId = req.user.id;
    var dupQuery = "select fn_get_contact_finaldata('" + searchtext + "','" + SELECTIONS + "');";
    runQueryNResult(req, res,dupQuery,'fn_get_contact_finaldata',[]);
}
exports.UpdateRecord = function(req, res){    
    checklogin(req, res);
    var userId = req.user.id;
    //var userId = req.user._id;
    var id = req.body.id;
    var group_id = req.body.group_id;
    var action = req.body.action;
    var ordinal = req.body.ordinal;
    var comment = req.body.comment;
    //console.log("comment=="+comment+"====");
    var dupQuery = "select fn_set_contact_selections_dynamic('" + id + "'," + ordinal + ",'" + action + "'," + group_id + "," + userId + ",'" + comment + "');";
    runQueryNResult(req, res,dupQuery,'fn_set_contact_selections_dynamic',[]);

}

function checklogin(req, res){
     var userId = req.user.id;

        if (typeof(userId) === 'undefined') {
            res.json({
                status: 400,
                message: "you are not logged in"
            });
        }
}
function runQueryNResult(req, res,Query,spname,parm){    
       var QueryInfo = dbHelper.runQuery(Query, parm);

        QueryInfo.then(function(duplicates) {
           
            if (duplicates.length === 0) {
                res.json({
                    status: 400,
                    data: "problem in running query"
                });

            } else {              
                               
                res.json({
                    status: 200,
                    message: "data",
                    data: JSON.parse(duplicates.rows[0][""+spname+""]) 
                });
            }
        });
    
}

